# Website dengan brand "Saliyah Macky"
Website ini menampilkan profil, karya, prestasi, dan informasi kontak dari **Saliyah Macky** (saya sendiri).

## Overview Halaman
**Beranda**: Profil singkat dan biodata
**Portfolio**: Daftar proyek/karya yang pernah dibuat
**Prestasi**: Sertfikat-sertfikat pencapaian akademik/non-akademik
**Contact**: Informasi dan form kontak

## Project Structure
**UTS**
    **index.html** (Halaman Beranda)
    **portfolio.html** (Halaman Portfolio)
    **css**
        **style.css** (Styling CSS external)
    **js**
        **script.js** (Animasi JavaScript basic)

## Teknologi yang Digunakan
**HTML5**
**CSS3** (untuk styling custom dan pengaturan layout)
**Javascript** (untuk animasi 'fade up' pada elemen card)
**[Bootstrap 5](https://getbootstrap.com/)** (sebagai framework untuk layout yang responsive dan untuk komponen UI)

## Fitur
Design yang responsive untuk desktop maupun mobile
Animasi pada card yang smooth menggunakan Javascript untuk memberikan efek 'fade up'
Layout yang minimalist dan clear berfokus pada konten.

## Styling
Menggunakan nuansa soft beige (`#f8f5f2`) dan aksen coklat (`#5C4033`)
Cards rounded Bootstrap yang memiliki efek shadow
Font menggunakan 'Segoe UI'
animasi hover dan lainnya dikostumasikan menggunakan CSS dan JS external

## Cara Menjalankan
1. Unduh file zip 'UTS.zip'
2. Buka 'index.html' di browser
3. Navigasikan halaman-halaman yang berbeda menggunakan navbar di atas.

## Author
Website ini dikembangkan oleh **Saliyah Macky** (saya sendiri) untuk memenuhi penilaian Ujian Tengah Semester mata kuliah Pemrograman Berbasis Web.